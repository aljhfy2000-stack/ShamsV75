package com.shams.locationtest;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.graphics.Color;

import java.util.Locale;

public class MainActivity extends Activity {

    private static final int REQ_LOCATION = 7001;
    private LocationManager locationManager;
    private TextView status;
    private TextView result;
    private LocationListener listener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(32, 40, 32, 32);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setBackgroundColor(Color.rgb(16, 24, 32));

        TextView title = new TextView(this);
        title.setText("اختبار الموقع الحقيقي للهاتف");
        title.setTextColor(Color.WHITE);
        title.setTextSize(25);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, 25);
        box.addView(title, new LinearLayout.LayoutParams(-1, -2));

        status = new TextView(this);
        status.setText("اضغط الزر لبدء الاختبار");
        status.setTextColor(Color.LTGRAY);
        status.setTextSize(18);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, 10, 0, 25);
        box.addView(status, new LinearLayout.LayoutParams(-1, -2));

        Button test = new Button(this);
        test.setText("📍 اختبار موقع الجهاز الآن");
        test.setTextSize(19);
        test.setOnClickListener(v -> startLocationTest());
        box.addView(test, new LinearLayout.LayoutParams(-1, 65));

        result = new TextView(this);
        result.setTextColor(Color.WHITE);
        result.setTextSize(18);
        result.setPadding(0, 35, 0, 20);
        result.setGravity(Gravity.CENTER);
        box.addView(result, new LinearLayout.LayoutParams(-1, -2));

        TextView note = new TextView(this);
        note.setText("هذا اختبار Android أصلي، وليس HTML أو htmltoapk.\n\nسيحاول استخدام GPS والشبكة/Wi‑Fi/الخدمات المتاحة في الهاتف. لا يستخدم IP لتحديد موقعك.");
        note.setTextColor(Color.LTGRAY);
        note.setTextSize(15);
        note.setGravity(Gravity.CENTER);
        box.addView(note, new LinearLayout.LayoutParams(-1, -2));

        ScrollView scroll = new ScrollView(this);
        scroll.addView(box);
        setContentView(scroll);

        listener = new LocationListener() {
            @Override public void onLocationChanged(Location location) {
                showLocation(location);
                stopUpdates();
            }
            @Override public void onProviderEnabled(String provider) {}
            @Override public void onProviderDisabled(String provider) {}
        };
    }

    private void startLocationTest() {
        if (!hasLocationPermission()) {
            status.setText("سيظهر طلب صلاحية الموقع من Android...");
            requestPermissions(new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
            }, REQ_LOCATION);
            return;
        }

        if (!isLocationEnabled()) {
            status.setText("خدمة الموقع في Android مغلقة. فعّل الموقع ثم اضغط الزر مرة أخرى.");
            try {
                startActivity(new android.content.Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
            } catch (Exception ignored) {}
            return;
        }

        result.setText("");
        status.setText("جارٍ طلب إحداثيات فعلية من الهاتف...");

        boolean requested = false;

        try {
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locationManager.requestLocationUpdates(
                        LocationManager.NETWORK_PROVIDER, 1000L, 0f, listener);
                requested = true;
            }
        } catch (SecurityException ignored) {}

        try {
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locationManager.requestLocationUpdates(
                        LocationManager.GPS_PROVIDER, 1000L, 0f, listener);
                requested = true;
            }
        } catch (SecurityException ignored) {}

        // Immediately show a recent location if Android already has one.
        Location recent = null;
        try {
            Location n = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            Location g = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (g != null) recent = g;
            if (n != null && (recent == null || n.getTime() > recent.getTime())) recent = n;
        } catch (SecurityException ignored) {}

        if (recent != null) {
            showLocation(recent);
        } else if (!requested) {
            status.setText("لم يتمكن Android من تشغيل مزود الموقع. تأكد من تفعيل GPS/الموقع.");
        }
    }

    private void showLocation(Location loc) {
        String provider = loc.getProvider() == null ? "غير معروف" : loc.getProvider();
        double lat = loc.getLatitude();
        double lon = loc.getLongitude();
        float acc = loc.hasAccuracy() ? loc.getAccuracy() : -1f;

        status.setText("تم استلام إحداثيات من الهاتف ✓");
        String accuracyText = acc >= 0
                ? String.format(Locale.US, "%.1f متر", acc)
                : "غير متاحة";

        result.setText(
                "خط العرض\n" + String.format(Locale.US, "%.7f", lat) +
                "\n\nخط الطول\n" + String.format(Locale.US, "%.7f", lon) +
                "\n\nالمصدر: " + provider +
                "\nالدقة: " + accuracyText
        );
    }

    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean isLocationEnabled() {
        try {
            return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
                    || locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        } catch (Exception e) {
            return false;
        }
    }

    private void stopUpdates() {
        try {
            locationManager.removeUpdates(listener);
        } catch (SecurityException ignored) {}
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopUpdates();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION) {
            if (hasLocationPermission()) {
                status.setText("تم السماح بالموقع. اضغط الزر مرة أخرى لبدء الاختبار.");
            } else {
                status.setText("تم رفض صلاحية الموقع.");
            }
        }
    }
}
